def playlist_ids() -> dict:
    playlists = {
        'top50uk': '37i9dQZEVXbLnolsZ8PSNw',
        'top50global': '37i9dQZEVXbMDoHDwVN2tF'
    }
    return playlists
